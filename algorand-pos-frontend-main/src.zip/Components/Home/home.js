import '../../App.css';

export default function Home() {
    return (
        <div className="App">
            <button>
                Start Order
            </button>
            <button>
                Edit Menu
            </button>
        </div>
    );
}